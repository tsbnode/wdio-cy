/// <reference types="cypress" />

describe('example to-do app', () => {
  before(() => {

      //loading the url once for all the tests
      cy.visit('https://todomvc.com/examples/react/#/')
    
  })

 
  it('can add new todo item1', () => {
 
    const newItem = 'item1 Get up at 6:30'
    var itemcount = 0;
    
    
    cy.get('.new-todo').type(`${newItem}{enter}`)

 
    itemcount = cy.get('.todo-count').find('strong')

 
    cy.get('.todo-list li')
      .should('have.length', 1)
      .last()
      .should('have.text', newItem)
  
      cy.get('footer').find('strong').should('have.text',1)

  })
  it('can add new todo item2', () => {
    
    const newItem = 'item2 Get ready'
    var itemcount = 0;
    
    cy.get('.new-todo').type(`${newItem}{enter}`)

   
    cy.get('.todo-list li')
      .should('have.length', 2)
      .last()
      .should('have.text', newItem)
   

  })
  it('can add new todo item3', () => {
 
    const newItem = 'item3 Go for a walk'
    var itemcount = 0;
    
       cy.get('.new-todo').type(`${newItem}{enter}`)

    cy.get('.todo-list li')
      .should('have.length', 3)
      .last()
      .should('have.text', newItem)
    
      cy.get('footer').find('strong').should('have.text', 3)

  })


  it('strike off an item as completed', () => {
  
    cy.contains('item3 Go for a walk')
      .parent()
      .find('input[type=checkbox]')
      .check()

   
    cy.contains('item3 Go for a walk')
      .parents('li')
      .should('have.class', 'completed')
  })

  context('todo Actions', () => {
    beforeEach(() => {
     
      cy.contains('item')
        .parent()
        .find('input[type=checkbox]')
        .check()
    })

    it('can filter for uncompleted tasks', () => {
    
      cy.contains('Active').click()

      cy.get('.todo-list li')
        .should('have.length.greaterThan', 0)
        .first()
     
      cy.contains('item3 Go for a walk').should('not.exist')
    })

    it('can filter for completed tasks', () => {
      cy.contains('Completed').click()

      cy.get('.todo-list li')
      .should('have.length.greaterThan', 0)
        .first()
 
    })

    it('can delete all completed tasks', () => {
      cy.contains('Clear completed').click()
   
      cy.contains('Clear completed').should('not.exist')
    })
  })
})
